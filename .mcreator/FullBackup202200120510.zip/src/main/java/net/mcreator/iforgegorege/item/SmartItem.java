
package net.mcreator.iforgegorege.item;

public class SmartItem extends Item {
	public SmartItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE).stacksTo(1).jukeboxPlayable(ResourceKey.create(Registries.JUKEBOX_SONG, ResourceLocation.fromNamespaceAndPath(IForgeGoregeMod.MODID, "smart"))));
	}
}
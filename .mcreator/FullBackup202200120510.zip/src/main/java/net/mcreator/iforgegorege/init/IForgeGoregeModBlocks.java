
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.iforgegorege.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.iforgegorege.block.SUNBlock;
import net.mcreator.iforgegorege.block.NutgamingBlock;
import net.mcreator.iforgegorege.block.LevodidPortalBlock;
import net.mcreator.iforgegorege.block.DontBlock;
import net.mcreator.iforgegorege.block.BedrockStairsBlock;
import net.mcreator.iforgegorege.IForgeGoregeMod;

public class IForgeGoregeModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, IForgeGoregeMod.MODID);
	public static final RegistryObject<Block> SUN = REGISTRY.register("sun", () -> new SUNBlock());
	public static final RegistryObject<Block> NUTGAMING = REGISTRY.register("nutgaming", () -> new NutgamingBlock());
	public static final RegistryObject<Block> LEVODID_PORTAL = REGISTRY.register("levodid_portal", () -> new LevodidPortalBlock());
	public static final RegistryObject<Block> BEDROCK_STAIRS = REGISTRY.register("bedrock_stairs", () -> new BedrockStairsBlock());
	public static final RegistryObject<Block> DONT = REGISTRY.register("dont", () -> new DontBlock());
}

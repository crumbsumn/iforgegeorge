
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.iforgegorege.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.iforgegorege.client.gui.IphoneGUIScreen;
import net.mcreator.iforgegorege.client.gui.BeanselectScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class IForgeGoregeModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(IForgeGoregeModMenus.IPHONE_GUI, IphoneGUIScreen::new);
			MenuScreens.register(IForgeGoregeModMenus.BEANSELECT, BeanselectScreen::new);
		});
	}
}

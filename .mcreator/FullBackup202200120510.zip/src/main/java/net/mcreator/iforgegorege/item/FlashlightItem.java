
package net.mcreator.iforgegorege.item;

import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.InteractionResult;

import net.mcreator.iforgegorege.procedures.FlashlightRightClickedOnBloturnblocksintofglowstoneProcedure;
import net.mcreator.iforgegorege.init.IForgeGoregeModTabs;

public class FlashlightItem extends Item {
	public FlashlightItem() {
		super(new Item.Properties().tab(IForgeGoregeModTabs.TAB_ITEMS).stacksTo(64).rarity(Rarity.COMMON));
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.EAT;
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		InteractionResult retval = super.useOn(context);
		FlashlightRightClickedOnBloturnblocksintofglowstoneProcedure.execute(context.getLevel(), context.getClickedPos().getX(),
				context.getClickedPos().getY(), context.getClickedPos().getZ());
		return retval;
	}
}

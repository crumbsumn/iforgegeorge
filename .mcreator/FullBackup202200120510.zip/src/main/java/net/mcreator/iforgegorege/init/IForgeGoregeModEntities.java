
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.iforgegorege.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.iforgegorege.entity.RocketlauncherEntity;
import net.mcreator.iforgegorege.entity.LeminigunEntity;
import net.mcreator.iforgegorege.entity.JellybeanEntity;
import net.mcreator.iforgegorege.entity.FloppaEntity;
import net.mcreator.iforgegorege.IForgeGoregeMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class IForgeGoregeModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, IForgeGoregeMod.MODID);
	public static final RegistryObject<EntityType<LeminigunEntity>> LEMINIGUN = register("projectile_leminigun",
			EntityType.Builder.<LeminigunEntity>of(LeminigunEntity::new, MobCategory.MISC).setCustomClientFactory(LeminigunEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<JellybeanEntity>> JELLYBEAN = register("jellybean",
			EntityType.Builder.<JellybeanEntity>of(JellybeanEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(JellybeanEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<RocketlauncherEntity>> ROCKETLAUNCHER = register("projectile_rocketlauncher",
			EntityType.Builder.<RocketlauncherEntity>of(RocketlauncherEntity::new, MobCategory.MISC).setCustomClientFactory(RocketlauncherEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<FloppaEntity>> FLOPPA = register("floppa",
			EntityType.Builder.<FloppaEntity>of(FloppaEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(FloppaEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			JellybeanEntity.init();
			FloppaEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(JELLYBEAN.get(), JellybeanEntity.createAttributes().build());
		event.put(FLOPPA.get(), FloppaEntity.createAttributes().build());
	}
}

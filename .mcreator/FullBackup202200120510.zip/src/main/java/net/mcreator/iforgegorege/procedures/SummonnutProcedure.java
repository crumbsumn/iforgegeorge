package net.mcreator.iforgegorege.procedures;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.client.Minecraft;

import net.mcreator.iforgegorege.init.IForgeGoregeModEnchantments;

import java.util.Random;

public class SummonnutProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		ItemStack pickaxe = ItemStack.EMPTY;
		double ecnahntLevel = 0;
		double enchantLevel = 0;
		double EnchtSize = 0;
		double i = 0;
		double j = 0;
		double k = 0;
		if (!entity.isShiftKeyDown()) {
			pickaxe = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
			EnchtSize = EnchantmentHelper.getItemEnchantmentLevel(IForgeGoregeModEnchantments.NUT.get(), pickaxe);
			i = x - EnchtSize;
			for (int index0 = 0; index0 < (int) (EnchtSize * 2 + 1); index0++) {
				j = y - EnchtSize;
				for (int index1 = 0; index1 < (int) (EnchtSize * 2 + 1); index1++) {
					k = z - EnchtSize;
					for (int index2 = 0; index2 < (int) (EnchtSize * 2 + 1); index2++) {
						if (world.getBlockState(new BlockPos(i, j, k)).canOcclude()
								&& pickaxe.getItem().isCorrectToolForDrops((world.getBlockState(new BlockPos(i, j, k))))
								&& world.getBlockState(new BlockPos(i, j, k)).getDestroySpeed(world, new BlockPos(i, j, k)) >= 0) {
							if (new Object() {
								public boolean checkGamemode(Entity _ent) {
									if (_ent instanceof ServerPlayer _serverPlayer) {
										return _serverPlayer.gameMode.getGameModeForPlayer() == GameType.CREATIVE;
									} else if (_ent.level.isClientSide() && _ent instanceof Player _player) {
										return Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()) != null
												&& Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId())
														.getGameMode() == GameType.CREATIVE;
									}
									return false;
								}
							}.checkGamemode(entity)) {
								world.destroyBlock(new BlockPos(i, j, k), false);
							} else {
								{
									BlockPos _pos = new BlockPos(i, j, k);
									Block.dropResources(world.getBlockState(_pos), world, new BlockPos(i, j, k), null);
									world.destroyBlock(_pos, false);
								}
								{
									ItemStack _ist = pickaxe;
									if (_ist.hurt(1, new Random(), null)) {
										_ist.shrink(1);
										_ist.setDamageValue(0);
									}
								}
							}
						}
						k = k + 1;
					}
					j = j + 1;
				}
				i = i + 1;
			}
		}
	}
}

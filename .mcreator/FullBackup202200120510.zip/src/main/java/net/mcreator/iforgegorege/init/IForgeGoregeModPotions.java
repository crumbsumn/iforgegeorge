
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.iforgegorege.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.iforgegorege.IForgeGoregeMod;

public class IForgeGoregeModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, IForgeGoregeMod.MODID);
	public static final RegistryObject<Potion> LEAN = REGISTRY.register("lean",
			() -> new Potion(new MobEffectInstance(MobEffects.LUCK, 4000, 0, false, true),
					new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 4000, 2, false, true),
					new MobEffectInstance(MobEffects.HEAL, 4000, 1, false, true),
					new MobEffectInstance(MobEffects.DAMAGE_BOOST, 4000, 2, false, true),
					new MobEffectInstance(MobEffects.WATER_BREATHING, 4000, 1, false, true)));
}
